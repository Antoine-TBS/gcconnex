# GCconnex emergency PHP: interactive PR impact map

Unzip this package and open gcconnex-pr-impact.html in a modern browser. No installation, server, external library or network connection is required for the visualization. Source citation links navigate to GitHub only when clicked.

Source: map-repository-architecture skill, installed on the author's Mac and also present at TBS-AI-skills/skills/map-repository-architecture. Only the generated review artifacts are packaged here.

Base / merge base: bb89db027da3fac41d9248283cdb5f60812ae49c
Head: 112a3f1260bafd1d28af754667c6cdacc2b72ecc
One logical repository, two revision snapshots. Head links resolve once the reviewed branch is published to Antoine-TBS/gcconnex.

Scope: main Docker build, PHP source/package provenance, startup checks and documented deployment procedure. This is not a whole-application architecture/security audit. The base recipe is not claimed to reproduce the supplied production image. Changes to build dependency resolution preserve the supplied donor vendor artifacts, rather than asserting equivalence to a fresh base Composer install.

Green = added; blue = modified; red dashed = base-only/removed; grey = unchanged context. Delta counters count mapped nodes, edges and flows, not vulnerabilities. Removed interfaces remain visible as tombstones and are labelled REMOVED. Conditional release operations describe the intended runbook; no Azure deployment is shown as completed.

Local executable QA belongs to commit 7881c90b77d9c8318db72f009b9777b6ef365208. The mapped head adds deployment documentation only. See the PR for TLS, application-test, browser and production-verification limits. Architecture source validation is separate evidence from runtime testing.

The local base, head and comparison models passed strict Git-object/line/blob citation validation with zero warnings. Comparison: 13 nodes, 14 edges, 3 flows. Public model omits local checkout paths. HTML has a hash-authorized script and restrictive CSP, with no runtime external requests.

Browser checks: component selection; both inspector modes; source citation URLs; flow selection; step; play/pause/resume; clear/Escape; zoom/reset; light/dark; keyboard Enter activation; desktop 1920x1080 and mobile 390x844 without horizontal page overflow. Pan tested with browser-dispatched pointer events. Reduced-motion step tested using a temporary matchMedia simulation, not an operating-system preference change. No application was started or exercised for these viewer checks.

Presentation-only adaptations to the generated viewer: stacked mobile layout, explicit change legend, revision-count label and layout coordinates. No application source or runtime patch changed.

Publication is on hold. This archive is prepared locally for attachment when PR publication is authorized.
